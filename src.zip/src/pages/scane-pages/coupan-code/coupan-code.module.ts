import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CoupanCodePage } from './coupan-code';

@NgModule({
  declarations: [
    CoupanCodePage,
  ],
  imports: [
    IonicPageModule.forChild(CoupanCodePage),
  ],
})
export class CoupanCodePageModule {}
