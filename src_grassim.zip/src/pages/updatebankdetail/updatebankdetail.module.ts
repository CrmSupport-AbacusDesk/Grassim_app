import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdatebankdetailPage } from './updatebankdetail';

@NgModule({
  declarations: [
    UpdatebankdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdatebankdetailPage),
  ],
})
export class UpdatebankdetailPageModule {}
